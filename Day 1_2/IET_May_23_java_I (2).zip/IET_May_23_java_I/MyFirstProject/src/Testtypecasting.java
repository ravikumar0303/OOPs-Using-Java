
public class Testtypecasting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=34;
		short s=(short)i;
		long l=34;
		float f=l;

	}

}
